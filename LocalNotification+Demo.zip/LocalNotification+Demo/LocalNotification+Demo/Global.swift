import UIKit
import SystemConfiguration

class Global: NSObject {

}

extension UIColor {
    
    convenience init(hexString:NSString) {
        let hexString:NSString = hexString.trimmingCharacters(in: NSCharacterSet.whitespacesAndNewlines) as NSString
        let scanner = Scanner(string: hexString as String)
        
        if (hexString.hasPrefix("#")) {
            scanner.scanLocation = 1
        }
        
        var color:UInt32 = 0
        scanner.scanHexInt32(&color)
        
        let mask = 0x000000FF
        let r = Int(color >> 16) & mask
        let g = Int(color >> 8) & mask
        let b = Int(color) & mask
        
        let red   = CGFloat(r) / 255.0
        let green = CGFloat(g) / 255.0
        let blue  = CGFloat(b) / 255.0
        
        self.init(red:red, green:green, blue:blue, alpha:1)
    }
    
    func toHexString() -> String {
        var r:CGFloat = 0
        var g:CGFloat = 0
        var b:CGFloat = 0
        var a:CGFloat = 0
        
        getRed(&r, green: &g, blue: &b, alpha: &a)
        
        let rgb:Int = (Int)(r*255)<<16 | (Int)(g*255)<<8 | (Int)(b*255)<<0
        
        return NSString(format:"#%06x", rgb) as String
    }
}

extension UIView
{
    func setCornerRadius()
    {
        self.layer.cornerRadius = self.frame.size.height / 2
        self.clipsToBounds = true
    }
    
    func setViewBorderlColor()
    {
        self.layer.borderColor = UIColor.white.cgColor
        self.layer.borderWidth = 1.0
    }
    
    func setToolbarBorder(borderclr : String)
    {
        self.layer.cornerRadius = self.frame.size.height / 2
        self.clipsToBounds = true
        self.layer.borderColor = UIColor.init(hexString: borderclr as NSString).cgColor
        self.layer.borderWidth = 1.0
    }
    
    func removeToolbarBorder()
    {
        self.layer.borderColor = UIColor.clear.cgColor
    }
}

extension UIImageView
{
    func setImagecornerRadius()
    {
        self.layer.cornerRadius = self.frame.size.height / 2
        self.clipsToBounds = true
    }
}


extension UIButton
{
    func setButtonRadius(isBorder : Bool)
    {
        self.layer.cornerRadius = self.frame.size.height / 2
        self.clipsToBounds = true
        self.layer.borderColor = isBorder == true ? UIColor.white.cgColor : UIColor.clear.cgColor
        self.layer.borderWidth = 2.0
    }
}

let dateFormatter = DateFormatter()
let gregorian = Calendar(identifier: .gregorian)
extension Date {
    var millisecondsSince:String {
        return String.init(format: "%.0f", self.timeIntervalSince1970 * 1000.0)
    }
    
    func MStoString() -> String {
        dateFormatter.timeZone = TimeZone.current
        var strFormat = "MMM,dd yyyy"
        dateFormatter.dateFormat = strFormat //"dd MMM yyyy"
        return dateFormatter.string(from: self)
    }
    
    func MStoStringDDMMMYYYY() -> String {
        dateFormatter.timeZone = TimeZone.current
        var strFormat = "dd MMM,yyyy"
        dateFormatter.dateFormat = strFormat //"dd MMM yyyy"
        return dateFormatter.string(from: self)
    }
    
    
    func MStoStringFullDate() -> String {
        dateFormatter.timeZone = TimeZone.current
        var strFormat = "dd MMM yyyy"
        dateFormatter.dateFormat = strFormat + " HH:mm a"
        return dateFormatter.string(from: self)
    }
    
    func MonthName() -> String
    {
        let calendar = Calendar.current
        let month = calendar.component(.month, from: self)
        let year = calendar.component(.year, from: self)
        dateFormatter.dateFormat = "MM"
        return "\(dateFormatter.monthSymbols[month - 1])," + " \(year)"
    }
    
    func convertDateTimeToString() -> String {
        dateFormatter.timeZone = TimeZone.current
        dateFormatter.dateFormat = "dd/MM/yyyy"
        return dateFormatter.string(from: self)
    }
    
    func convertDateEndDate() -> String {
        var components = gregorian.dateComponents([.year, .month, .day, .hour, .minute, .second], from: self)
        components.hour = 23
        components.minute = 59
        components.second = 59
        return "\(gregorian.date(from: components)!.millisecondsSince)"
    }
    
    func convertDateStartDate() -> String {
        var components = gregorian.dateComponents([.year, .month, .day, .hour, .minute, .second], from: self)
        components.hour = 0
        components.minute = 0
        components.second = 0
        return "\(gregorian.date(from: components)!.millisecondsSince)"
    }
    
    func convertDateToUserFormat() -> String {
        var strFormat = "dd/MM/yyyy"
        dateFormatter.dateFormat = strFormat
        return dateFormatter.string(from: self)
    }
}

extension String
{
    func isvalidString() -> Bool
    {
        var isvalid = Bool()
        if self.trimmingCharacters(in: .whitespacesAndNewlines).count <= 0
        {
            isvalid = true
        }
        else{
            isvalid = false
        }
        return isvalid
    }
    
    func isValidEmail() -> Bool
    {
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,3}"
        let emailTest = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        return emailTest.evaluate(with: self)
    }
    
    var MStoDate: String {
        return Date(timeIntervalSince1970: (TimeInterval(Int(self)! / 1000))).MStoString()
    }
    
    var MStoDateAccountDetails: String {
        return Date(timeIntervalSince1970: (TimeInterval(Int(self)! / 1000))).MStoStringDDMMMYYYY()
    }
    
    var MStoFullDate: String {
        return Date(timeIntervalSince1970: (TimeInterval(Int(self)! / 1000))).MStoStringFullDate()
    }
    
    var MStoDateToDate: String {
        return Date(timeIntervalSince1970: (TimeInterval(Int(self)! / 1000))).convertDateToUserFormat()
    }
}

public extension UIDevice {
    
    @objc var iPhone: Bool {
        return UIDevice().userInterfaceIdiom == .phone
    }
    
    enum ScreenType: String {
        case iPhone4
        case iPhone5
        case iPhone6
        case iPhone6Plus
        case iPhoneX
        case Unknown
    }
    var screenType: ScreenType {
        guard iPhone else { return .Unknown}
        if max(UIScreen.main.bounds.size.width, UIScreen.main.bounds.size.height) < 568 {
            return .iPhone4
        }
        else if max(UIScreen.main.bounds.size.width, UIScreen.main.bounds.size.height) == 568 {
            return .iPhone5
        }
        else if max(UIScreen.main.bounds.size.width, UIScreen.main.bounds.size.height) == 667 {
            return .iPhone6
        }
        else if max(UIScreen.main.bounds.size.width, UIScreen.main.bounds.size.height) == 736 {
            return .iPhone6Plus
        }
        else if max(UIScreen.main.bounds.size.width, UIScreen.main.bounds.size.height) == 812 {
            return .iPhoneX
        }
        else{
            return .Unknown
        }
    }
    
    var modelName: String {
        var systemInfo = utsname()
        uname(&systemInfo)
        let machineMirror = Mirror(reflecting: systemInfo.machine)
        let identifier = machineMirror.children.reduce("") { identifier, element in
            guard let value = element.value as? Int8, value != 0 else { return identifier }
            return identifier + String(UnicodeScalar(UInt8(value)))
        }
        
        switch identifier {
        case "iPod5,1":                                 return "iPod Touch 5"
        case "iPod7,1":                                 return "iPod Touch 6"
        case "iPhone3,1", "iPhone3,2", "iPhone3,3":     return "iPhone 4"
        case "iPhone4,1":                               return "iPhone 4s"
        case "iPhone5,1", "iPhone5,2":                  return "iPhone 5"
        case "iPhone5,3", "iPhone5,4":                  return "iPhone 5c"
        case "iPhone6,1", "iPhone6,2":                  return "iPhone 5s"
        case "iPhone7,2":                               return "iPhone 6"
        case "iPhone7,1":                               return "iPhone 6 Plus"
        case "iPhone8,1":                               return "iPhone 6s"
        case "iPhone8,2":                               return "iPhone 6s Plus"
        case "iPhone9,1", "iPhone9,3":                  return "iPhone 7"
        case "iPhone9,2", "iPhone9,4":                  return "iPhone 7 Plus"
        case "iPhone10,1", "iPhone10,4":                return "iPhone 8"
        case "iPhone10,2", "iPhone10,5":                return "iPhone 8 Plus"
        case "iPhone10,3", "iPhone10,6":                return "iPhone X"
        case "iPhone8,4":                               return "iPhone SE"
        case "iPad2,1", "iPad2,2", "iPad2,3", "iPad2,4":return "iPad 2"
        case "iPad3,1", "iPad3,2", "iPad3,3":           return "iPad 3"
        case "iPad3,4", "iPad3,5", "iPad3,6":           return "iPad 4"
        case "iPad4,1", "iPad4,2", "iPad4,3":           return "iPad Air"
        case "iPad5,3", "iPad5,4":                      return "iPad Air 2"
        case "iPad6,11", "iPad6,12":                    return "iPad 5"
        case "iPad2,5", "iPad2,6", "iPad2,7":           return "iPad Mini"
        case "iPad4,4", "iPad4,5", "iPad4,6":           return "iPad Mini 2"
        case "iPad4,7", "iPad4,8", "iPad4,9":           return "iPad Mini 3"
        case "iPad5,1", "iPad5,2":                      return "iPad Mini 4"
        case "iPad6,3", "iPad6,4":                      return "iPad Pro 9.7 Inch"
        case "iPad6,7", "iPad6,8":                      return "iPad Pro 12.9 Inch"
        case "iPad7,1", "iPad7,2":                      return "iPad Pro 12.9 Inch 2. Generation"
        case "iPad7,3", "iPad7,4":                      return "iPad Pro 10.5 Inch"
        case "AppleTV5,3":                              return "Apple TV"
        case "i386", "x86_64":                          return "Simulator"
        default:                                        return identifier
        }
    }
}


//func alert(title:String, msg:String) -> Void
//{
//    let alert = UIAlertController(title: title, message: msg, preferredStyle: UIAlertControllerStyle.alert)
//    alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
//    APPDELEGATE.window?.rootViewController?.present(alert, animated: true, completion: nil)
//}

//MARK:- Reachablity

public class Reachability {
    
    class func isConnectedToNetwork() -> Bool {
        
        var zeroAddress = sockaddr_in(sin_len: 0, sin_family: 0, sin_port: 0, sin_addr: in_addr(s_addr: 0), sin_zero: (0, 0, 0, 0, 0, 0, 0, 0))
        zeroAddress.sin_len = UInt8(MemoryLayout.size(ofValue: zeroAddress))
        zeroAddress.sin_family = sa_family_t(AF_INET)
        
        let defaultRouteReachability = withUnsafePointer(to: &zeroAddress) {
            $0.withMemoryRebound(to: sockaddr.self, capacity: 1) {zeroSockAddress in
                SCNetworkReachabilityCreateWithAddress(nil, zeroSockAddress)
            }
        }
        
        var flags: SCNetworkReachabilityFlags = SCNetworkReachabilityFlags(rawValue: 0)
        if SCNetworkReachabilityGetFlags(defaultRouteReachability!, &flags) == false {
            return false
        }
        
        /* Only Working for WIFI
         let isReachable = flags == .reachable
         let needsConnection = flags == .connectionRequired
         
         return isReachable && !needsConnection
         */
        
        // Working for Cellular and WIFI
        let isReachable = (flags.rawValue & UInt32(kSCNetworkFlagsReachable)) != 0
        let needsConnection = (flags.rawValue & UInt32(kSCNetworkFlagsConnectionRequired)) != 0
        let ret = (isReachable && !needsConnection)
        
        return ret
        
    }
}

