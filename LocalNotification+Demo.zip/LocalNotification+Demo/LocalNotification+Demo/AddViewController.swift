


import UIKit

let kEventdata = "kEventdata"
let kEventName = "kEventName"
let kNotificationDate = "kNotificationDate"

class AddViewController: UIViewController
{

    @IBOutlet var textfieldEventName: UITextField!
    @IBOutlet var datePicker: UIDatePicker!
    var selectedDate = Date().millisecondsSince
    var arrayevent = NSMutableArray()
    var index:IndexPath!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.navigationController?.navigationBar.isHidden = true
        
        datePicker.addTarget(self, action: #selector(handleDatePicker(_:)), for: .valueChanged)
        
        if UserDefaults.standard.object(forKey: kEventdata) != nil
        {
            arrayevent = (UserDefaults.standard.object(forKey: kEventdata) as! NSMutableArray).mutableCopy() as! NSMutableArray
        }
        if index != nil
        {
            self.editRecord()
        }
    }
    
    func editRecord()
    {
        if let objDic:NSMutableDictionary = arrayevent.object(at: index.row) as? NSMutableDictionary
        {
            textfieldEventName.text = objDic.value(forKey: kEventName) as? String
//            let date = Date(timeIntervalSince1970: (Double(objDic.value(forKey: kNotificationDate)!)) / 1000.0)
//            datePicker.date = date
        }
    }
        
    @IBAction func buttonSave(_ sender: UIButton)
    {
        let dic = NSMutableDictionary()
        dic.setValue(textfieldEventName.text!, forKey: kEventName)
        dic.setValue(selectedDate, forKey: kNotificationDate)
        
        if index != nil
        {
            arrayevent.replaceObject(at: index.row, with: dic)
        }
        arrayevent.add(dic)
        
        UserDefaults.standard.set(arrayevent, forKey: kEventdata)
        UserDefaults.standard.synchronize()
        
        print(UserDefaults.standard.value(forKey: kEventdata)!)
        self.navigationController?.popViewController(animated: true)
    }
    
    @objc func handleDatePicker(_ sender: UIDatePicker)
    {
        selectedDate = sender.date.millisecondsSince
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
}
