

import UIKit

class ViewController: UIViewController ,UITableViewDelegate,UITableViewDataSource
{
    @IBOutlet var objtableview: UITableView!
    var arrayData = NSMutableArray()
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        self.objtableview.register(UITableViewCell.self, forCellReuseIdentifier: "cell")
        
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        self.navigationController?.navigationBar.isHidden = false
        if UserDefaults.standard.object(forKey: kEventdata) != nil
        {
            print(UserDefaults.standard.value(forKey: kEventdata)!)
            arrayData = (UserDefaults.standard.object(forKey: kEventdata) as! NSMutableArray).mutableCopy() as! NSMutableArray
            objtableview.reloadData()
        }
    }
    
    @IBAction func ButtonAdd(_ sender: UIBarButtonItem)
    {
        let objAddVC = self.storyboard?.instantiateViewController(withIdentifier:"AddViewController") as! AddViewController
        self.navigationController?.pushViewController(objAddVC, animated: true)
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell") as! UITableViewCell
        
        cell.textLabel?.text = (arrayData.object(at: indexPath.row) as! NSMutableDictionary).value(forKey: kEventName) as? String
        cell.detailTextLabel?.text = (arrayData.object(at: indexPath.row) as! NSMutableDictionary).value(forKey: kNotificationDate) as? String
        return cell
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrayData.count
    }
    
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            self.arrayData.remove(indexPath.row)
            objtableview.deleteRows(at: [indexPath], with: .fade)
        }
        else
        {
            
        }
    }
    
    func tableView(_ tableView: UITableView, editActionsForRowAt indexPath: IndexPath) -> [UITableViewRowAction]? {
        let delete = UITableViewRowAction(style: .destructive, title: "Delete") { (action, indexPath) in
            
            self.arrayData.remove(indexPath.row)
            tableView.deleteRows(at: [indexPath], with: .fade)
            print(self.arrayData)
        }
        
        let edit = UITableViewRowAction(style: .default, title: "Edit") { (action, indexPath) in
            let objAddVC = self.storyboard?.instantiateViewController(withIdentifier:"AddViewController") as! AddViewController
            objAddVC.index = indexPath
            self.navigationController?.pushViewController(objAddVC, animated: true)
        }
        edit.backgroundColor = UIColor.lightGray
        return [delete, edit]
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }


}

