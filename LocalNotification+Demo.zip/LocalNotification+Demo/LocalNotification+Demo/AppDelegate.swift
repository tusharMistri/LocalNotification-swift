

import UIKit
import UserNotifications

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate ,UNUserNotificationCenterDelegate
{
    var window: UIWindow?


    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplicationLaunchOptionsKey: Any]?) -> Bool {
        UserDefaults.standard.removeObject(forKey: kEventdata)
        self.initNotificationSetupCheck()
        return true
    }

    func applicationWillResignActive(_ application: UIApplication) {
    }

    func applicationDidEnterBackground(_ application: UIApplication) {
    }

    func applicationWillEnterForeground(_ application: UIApplication) {
    }

    func applicationDidBecomeActive(_ application: UIApplication) {
    }

    func applicationWillTerminate(_ application: UIApplication) {
    }

    //MARK:- UNUserNotificationCenterDelegate
    
    func userNotificationCenter(_ center: UNUserNotificationCenter, didReceive response: UNNotificationResponse, withCompletionHandler completionHandler: @escaping () -> Void) {
        print("response :\(response)")
    }
    
    func userNotificationCenter(_ center: UNUserNotificationCenter, willPresent notification: UNNotification, withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void) {
        print("notification :\(notification)")
    }
    
    //MARK:- Register LocalNotification
    
    func initNotificationSetupCheck() {
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert,.sound,.badge])
        { (success, error) in
            if success {
                print("Permission Granted")
//                self.setLocalNotification()
            } else {
                print("There was a problem!")
            }
        }
    }
    
    func setLocalNotification(bodyMsg:String,title:String , identifier:String)
    {
        let notification = UNMutableNotificationContent()
        notification.title = title
        //        notification.subtitle = "Something This Way Comes"
        notification.body = bodyMsg
        
        let notificationTrigger = UNTimeIntervalNotificationTrigger(timeInterval: 10, repeats: false)
        let request = UNNotificationRequest(identifier: identifier, content: notification, trigger: notificationTrigger)
        UNUserNotificationCenter.current().add(request, withCompletionHandler: nil)
        
    }
    
    func removeLocalNotification(identifier:String)
    {
        let currn = UNUserNotificationCenter.current()
        currn.removePendingNotificationRequests(withIdentifiers: [identifier])
    }
    
}

